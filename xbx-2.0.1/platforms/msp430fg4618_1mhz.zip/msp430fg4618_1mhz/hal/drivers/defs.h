#ifndef DEFS_H
#define DEFS_H

//Typedefs and other definitions
//
//part of serJTAGfirmware
//http://mspgcc.sf.net
//chris <cliechti@gmx.net>

#define __BYTEWORD__
typedef unsigned int  word;
typedef unsigned char byte;

#endif //DEFS_H
