#include <inttypes.h>
	
typedef uint32_t u_int32_t;
typedef uint64_t u_int64_t;